<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('testimonials', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('role'); // Ibu dari Kenzo (7th), Peserta TNI POLRI, Peserta Dewasa Pemula
            $table->string('program');
            $table->unsignedTinyInteger('rating')->default(5);
            $table->text('review');
            $table->string('avatar')->nullable();
            $table->string('video_url')->nullable();
            $table->boolean('is_featured')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('testimonials');
    }
};
