<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            <!-- Col 1: Brand Info & SEO Text -->
            <div>
                <div style="margin-bottom: 1.25rem;">
                    <img src="{{ asset('images/logo.webp') }}" alt="Les Renang Jogja Logo" style="height: 85px; width: auto; max-width: 320px; object-fit: contain; filter: drop-shadow(0 4px 12px rgba(0,0,0,0.3));">
                </div>
                <p style="font-size: 0.925rem; line-height: 1.7; margin-bottom: 1.5rem; color: #94a3b8;">
                    Pusat pelatihan & kursus privat renang terpercaya di Yogyakarta. Menyediakan program khusus anak-anak, dewasa pemula, privat wanita/muslimah, serta kelas intensif persiapan tes TNI, POLRI & Kedinasan.
                </p>
                <div style="display: flex; gap: 0.75rem;">
                    <a href="https://instagram.com" target="_blank" style="width: 38px; height: 38px; background: #1e293b; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; transition: background 0.2s;"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://tiktok.com" target="_blank" style="width: 38px; height: 38px; background: #1e293b; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; transition: background 0.2s;"><i class="fa-brands fa-tiktok"></i></a>
                    <a href="https://youtube.com" target="_blank" style="width: 38px; height: 38px; background: #1e293b; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; transition: background 0.2s;"><i class="fa-brands fa-youtube"></i></a>
                    <a href="https://wa.me/6281234567890" target="_blank" style="width: 38px; height: 38px; background: #25d366; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; transition: background 0.2s;"><i class="fa-brands fa-whatsapp"></i></a>
                </div>
            </div>

            <!-- Col 2: Navigation Links -->
            <div>
                <h4 class="footer-title">Program Pilihan</h4>
                <ul class="footer-links">
                    <li><a href="{{ route('program.show', 'les-renang-anak') }}">Les Renang Anak (3-15 Th)</a></li>
                    <li><a href="{{ route('program.show', 'les-renang-dewasa') }}">Les Renang Dewasa Pemula</a></li>
                    <li><a href="{{ route('program.show', 'les-renang-wanita') }}">Les Renang Wanita / Muslimah</a></li>
                    <li><a href="{{ route('program.show', 'persiapan-tni-polri') }}">Persiapan Tes TNI & POLRI</a></li>
                    <li><a href="{{ route('program.show', 'terapi-renang') }}">Terapi Renang Medis</a></li>
                    <li><a href="{{ route('program.show', 'corporate-training') }}">Corporate & Group Class</a></li>
                </ul>
            </div>

            <!-- Col 3: Service Areas (Target SEO keywords) -->
            <div>
                <h4 class="footer-title">Area Layanan</h4>
                <ul class="footer-links">
                    <li><a href="{{ route('lokasi') }}">Sleman & Depok (UNY / DSC)</a></li>
                    <li><a href="{{ route('lokasi') }}">Kota Yogyakarta & Umbulharjo</a></li>
                    <li><a href="{{ route('lokasi') }}">Bantul & Kasihan</a></li>
                    <li><a href="{{ route('lokasi') }}">Kulon Progo</a></li>
                    <li><a href="{{ route('lokasi') }}">Semarang & Solo</a></li>
                    <li><a href="{{ route('lokasi') }}">Magelang & Klaten</a></li>
                </ul>
            </div>

            <!-- Col 4: Contact & Hours -->
            <div>
                <h4 class="footer-title">Informasi & Kontak</h4>
                <div style="font-size: 0.9rem; margin-bottom: 1rem; color: #94a3b8;">
                    <p style="margin-bottom: 0.5rem;"><i class="fa-solid fa-location-dot" style="color: var(--primary); margin-right: 0.5rem;"></i> Head Office: Sleman, D.I. Yogyakarta</p>
                    <p style="margin-bottom: 0.5rem;"><i class="fa-brands fa-whatsapp" style="color: #25d366; margin-right: 0.5rem;"></i> +62 812-3456-7890 (Admin WA)</p>
                    <p style="margin-bottom: 0.5rem;"><i class="fa-regular fa-clock" style="color: var(--accent); margin-right: 0.5rem;"></i> Buka Setiap Hari: 06.00 - 20.00 WIB</p>
                </div>
                <button onclick="openTrialModal()" class="btn btn-accent btn-sm" style="width: 100%;">
                    <i class="fa-solid fa-bolt"></i> Booking Trial Gratis 30m
                </button>
            </div>
        </div>

        <div class="footer-bottom">
            <div>
                © {{ date('Y') }} <strong>Les Renang Jogja</strong>. Hak Cipta Dilindungi Undang-Undang.
            </div>
            <div style="display: flex; gap: 1.5rem; flex-wrap: wrap; justify-content: center;">
                <a href="{{ route('faq') }}" style="color: #64748b; text-decoration: none;">FAQ</a>
                <a href="{{ route('blog.index') }}" style="color: #64748b; text-decoration: none;">Artikel Tips</a>
                <a href="{{ route('kontak') }}" style="color: #64748b; text-decoration: none;">Hubungi Kami</a>
                <a href="{{ route('admin.login') }}" style="color: #64748b; text-decoration: none;"><i class="fa-solid fa-lock"></i> Admin Panel</a>
            </div>
        </div>
    </div>
</footer>
