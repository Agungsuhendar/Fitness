<nav class="navbar">
    <div class="container">
        <div class="navbar-inner">
            <!-- Brand Logo -->
            <a href="{{ route('home') }}" class="brand-logo" aria-label="Les Renang Jogja - Beranda">
                <img src="{{ asset('images/logo.webp') }}" alt="Les Renang Jogja Logo" class="brand-logo-img" style="height: 70px; max-height: 72px; width: auto; max-width: 300px; object-fit: contain;">
            </a>

            <!-- Desktop Nav Links -->
            <ul class="nav-links" id="mobileNavMenu">
                <li><a href="{{ route('home') }}" class="nav-link {{ request()->routeIs('home') ? 'active' : '' }}">Beranda</a></li>
                <li><a href="{{ route('tentang') }}" class="nav-link {{ request()->routeIs('tentang') ? 'active' : '' }}">Tentang</a></li>
                <li><a href="{{ route('program.index') }}" class="nav-link {{ request()->routeIs('program.*') ? 'active' : '' }}">Program</a></li>
                <li><a href="{{ route('lokasi') }}" class="nav-link {{ request()->routeIs('lokasi') ? 'active' : '' }}">Lokasi</a></li>
                <li><a href="{{ route('harga') }}" class="nav-link {{ request()->routeIs('harga') ? 'active' : '' }}">Harga</a></li>
                <li><a href="{{ route('testimoni') }}" class="nav-link {{ request()->routeIs('testimoni') ? 'active' : '' }}">Testimoni</a></li>
                <li><a href="{{ route('blog.index') }}" class="nav-link {{ request()->routeIs('blog.*') ? 'active' : '' }}">Blog</a></li>
                <li><a href="{{ route('faq') }}" class="nav-link {{ request()->routeIs('faq') ? 'active' : '' }}">FAQ</a></li>
                <li><a href="{{ route('kontak') }}" class="nav-link {{ request()->routeIs('kontak') ? 'active' : '' }}">Kontak</a></li>
            </ul>

            <!-- Header Actions -->
            <div class="nav-actions">
                <!-- Theme Switcher Widget -->
                <div class="theme-switcher-wrapper">
                    <button type="button" class="theme-toggle-btn" onclick="toggleThemeMenu(event)" aria-label="Pilih Tema Tampilan" title="Ganti Tema Tampilan">
                        <i class="fa-solid fa-droplet" id="themeToggleIcon"></i>
                    </button>

                    <div class="theme-dropdown-menu" id="themeDropdownMenu">
                        <div style="font-size: 0.75rem; font-weight: 800; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; padding: 0.4rem 0.6rem 0.2rem;">
                            <i class="fa-solid fa-palette" style="margin-right: 0.35rem;"></i> Pilih Tema
                        </div>
                        <button type="button" class="theme-option" data-theme="ocean" onclick="setTheme('ocean')">
                            <span class="theme-dot ocean"></span> 🌊 Ocean Aqua
                        </button>
                        <button type="button" class="theme-option" data-theme="dark" onclick="setTheme('dark')">
                            <span class="theme-dot dark"></span> 🌙 Mode Gelap
                        </button>
                        <button type="button" class="theme-option" data-theme="sunset" onclick="setTheme('sunset')">
                            <span class="theme-dot sunset"></span> 🌅 Sunset Lagoon
                        </button>
                        <button type="button" class="theme-option" data-theme="emerald" onclick="setTheme('emerald')">
                            <span class="theme-dot emerald"></span> 🌿 Emerald Mint
                        </button>
                    </div>
                </div>

                <!-- Mobile Hamburger Button -->
                <button class="mobile-toggle" id="mobileNavToggle" aria-label="Toggle Navigation">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
        </div>
    </div>
</nav>
