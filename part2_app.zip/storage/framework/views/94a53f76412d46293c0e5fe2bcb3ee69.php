<?php $__env->startSection('title', 'Program Les Renang Jogja - Anak, Dewasa, Wanita & TNI POLRI'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero-section" style="padding: 3rem 0;">
    <div class="container">
        <div style="text-align: center; max-width: 800px; margin: 0 auto;">
            <span class="section-subtitle">Pilihan Terbaik</span>
            <h1 class="hero-title">Program <span class="text-gradient">Les Renang Jogja</span></h1>
            <p class="hero-description">
                Temukan program latihan renang privat yang dirancang khusus sesuai kelompok usia dan target pencapaian Anda.
            </p>
        </div>
    </div>
</section>

<section class="section section-bg-alt">
    <div class="container">
        <div class="grid-3">
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="program-card">
                <div class="program-thumb">
                    <img src="<?php echo e(asset($prog->image)); ?>" alt="<?php echo e($prog->title); ?>">
                    <?php if($prog->badge): ?>
                        <span class="program-badge"><?php echo e($prog->badge); ?></span>
                    <?php endif; ?>
                </div>
                <div class="program-body">
                    <h2 class="program-title" style="font-size: 1.35rem;"><?php echo e($prog->title); ?></h2>
                    <div class="program-audience">
                        <i class="fa-solid fa-users"></i> <?php echo e($prog->target_audience); ?>

                    </div>
                    <p class="program-desc"><?php echo e($prog->description); ?></p>

                    <div class="program-footer">
                        <div class="price-tag">
                            Mulai dari<br>
                            <span>Rp <?php echo e(number_format($prog->price_start, 0, ',', '.')); ?></span>
                        </div>
                        <a href="<?php echo e(route('program.show', $prog->slug)); ?>" class="btn btn-outline btn-sm">
                            Lihat Detail <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/agungsuhendar/Les Renang/resources/views/program/index.blade.php ENDPATH**/ ?>