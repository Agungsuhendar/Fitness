<?php $__env->startSection('title', 'Blog & Tips Renang Jogja - Tips, Parenting, & Persiapan TNI'); ?>
<?php $__env->startSection('meta_description', 'Kumpulan artikel tips renang, kesehatan hydrotherapy, pola mengajar anak, & rahasia tes fisik TNI POLRI di Les Renang Jogja.'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero-section" style="padding: 3rem 0;">
    <div class="container">
        <div style="text-align: center; max-width: 800px; margin: 0 auto;">
            <span class="section-subtitle">Wawasan & Panduan</span>
            <h1 class="hero-title">Blog & <span class="text-gradient">Tips Renang</span></h1>
            <p class="hero-description">
                Artikel edukasi dari para instruktur profesional seputar teknik renang, parenting, kesehatan, dan persiapan ujian kesamaptaan.
            </p>
        </div>
    </div>
</section>

<!-- Category Filter & Search Bar -->
<section class="section" style="padding: 2rem 0; background: #ffffff;">
    <div class="container">
        <form action="<?php echo e(route('blog.index')); ?>" method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap; justify-content: center; align-items: center;">
            <a href="<?php echo e(route('blog.index')); ?>" class="btn btn-sm <?php echo e(!request('category') ? 'btn-primary' : 'btn-outline'); ?>">
                Semua Kategori
            </a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blog.index', ['category' => $cat])); ?>" class="btn btn-sm <?php echo e(request('category') == $cat ? 'btn-primary' : 'btn-outline'); ?>">
                    <?php echo e($cat); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </div>
</section>

<section class="section section-bg-alt">
    <div class="container">
        <div class="grid-3">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="glass-card" style="overflow: hidden; background: #ffffff;">
                <div style="height: 200px; overflow: hidden; background: #e0f2fe;">
                    <img src="<?php echo e(Str::startsWith($post->image, 'http') ? $post->image : asset($post->image)); ?>" alt="<?php echo e($post->title); ?>" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" onerror="this.onerror=null; this.src='<?php echo e(asset('images/assets/pool_uny.webp')); ?>';">
                </div>
                <div style="padding: 1.5rem;">
                    <div style="font-size: 0.8rem; font-weight: 700; color: var(--primary); margin-bottom: 0.5rem; text-transform: uppercase;">
                        <?php echo e($post->category); ?> • <?php echo e($post->reading_time); ?> Menit Baca
                    </div>
                    <h2 style="font-size: 1.2rem; margin-bottom: 0.75rem; line-height: 1.4;">
                        <a href="<?php echo e(route('blog.show', $post->slug)); ?>" style="text-decoration: none; color: var(--dark);"><?php echo e($post->title); ?></a>
                    </h2>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.25rem;"><?php echo e(Str::limit($post->excerpt, 100)); ?></p>
                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" style="font-weight: 700; color: var(--primary); text-decoration: none; font-size: 0.9rem;">
                        Baca Artikel Lengkap <i class="fa-solid fa-arrow-right"></i>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div style="margin-top: 2.5rem; display: flex; justify-content: center;">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/agungsuhendar/Les Renang/resources/views/blog/index.blade.php ENDPATH**/ ?>